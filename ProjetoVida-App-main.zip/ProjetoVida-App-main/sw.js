/* Service Worker — PWA (instalável + offline)
   ⚠️ Durante o desenvolvimento, o nav.js remove este registro.
   Reative na versão final da apresentação. */
const CACHE = 'vidaplus-app-v5';
const ARQUIVOS = [
  './',
  'index.html',
  'login.html',
  'fila.html',
  'consulta.html',
  'historico.html',
  'exames.html',
  'agendamentos.html',
  'notificacoes.html',
  'perfil.html',
  'manifest.json',
  'css/app.css',
  'js/config.js',
  'js/ui.js',
  'js/db.js',
  'js/notificacao.js',
  'js/nav.js',
  'icons/icon-192.png',
  'icons/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARQUIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(chaves =>
      Promise.all(chaves.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const ehPagina = e.request.mode === 'navigate';
  if (ehPagina) {
    e.respondWith(
      fetch(e.request)
        .then(resposta => {
          const copia = resposta.clone();
          caches.open(CACHE).then(c => c.put(e.request, copia));
          return resposta;
        })
        .catch(() => caches.match(e.request).then(r => r || caches.match('./')))
    );
    return;
  }
  e.respondWith(
    caches.match(e.request).then(resposta => {
      const buscar = fetch(e.request).then(nova => {
        caches.open(CACHE).then(c => c.put(e.request, nova.clone()));
        return nova;
      }).catch(() => null);
      return resposta || buscar;
    })
  );
});

/* Push OneSignal */
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(lista => {
    for (const c of lista) {
      if ('focus' in c) { c.focus(); return; }
    }
    return clients.openWindow('./fila.html');
  }));
});
