-- ============================================================
-- VIDA+ — BANCO DE DADOS COMPARTILHADO (Supabase / PostgreSQL)
-- ------------------------------------------------------------
-- Serve o APP DO PACIENTE e o SISTEMA MÉDICO (mesmo banco).
--
-- COMO USAR:
-- 1. Crie um projeto em https://supabase.com
-- 2. Menu "SQL Editor" → New query → cole este arquivo → RUN
-- 3. Copie a URL e a anon key no arquivo
--    app:      vida-plus-app/js/config.js  (SUPABASE_URL / KEY)
--
-- FLUXO DO ATENDIMENTO:
--   RECEPÇÃO cadastra paciente + inicia o atendimento (senha)
--   → ENFERMEIRA preenche triagem (queixa + sinais vitais)
--   → TELÃO chama (push OneSignal)
--   → MÉDICO finaliza (diagnóstico + medicamentos + exames)
--   → PACIENTE acompanha tudo no app (lê o que a equipe fez)
-- ============================================================

create extension if not exists "pgcrypto";

-- ============================================================
-- 1. PACIENTES (cadastro feito pela RECEPÇÃO; paciente só lê)
-- ============================================================
create table if not exists public.pacientes (
  id uuid primary key default gen_random_uuid(),
  cpf varchar(11) not null unique,
  nome varchar(160) not null,
  nascimento date,
  sexo varchar(1) check (sexo in ('F','M','O')),
  telefone varchar(20),
  email varchar(120),
  endereco varchar(255),
  tipo_sanguineo varchar(3),
  alergias text[] default '{}',
  doencas_cronicas text[] default '{}',
  medicamentos_uso text,
  deficiencia varchar(60),
  gestante boolean default false,
  tabagista boolean default false,
  responsavel_nome varchar(160),
  responsavel_telefone varchar(20),
  criado_em timestamptz default now(),
  atualizado_em timestamptz default now()
);

-- ============================================================
-- 2. USUÁRIOS DO SISTEMA MÉDICO (funcionários)
-- ============================================================
create table if not exists public.usuarios (
  id uuid primary key default gen_random_uuid(),
  nome varchar(160) not null,
  cpf varchar(11) unique,
  email varchar(120) unique,
  senha_hash text,
  perfil varchar(20) not null check (perfil in ('recepcionista','enfermeiro','medico','administrador')),
  registro_profissional varchar(30),
  ativo boolean default true,
  criado_em timestamptz default now()
);

-- ============================================================
-- 3. CONSULTAS (iniciada pela recepção → triagem → consulta)
-- ------------------------------------------------------------
-- status: em_fila → chamado → em_consulta → finalizado | cancelado
-- ============================================================
create table if not exists public.consultas (
  id uuid primary key default gen_random_uuid(),
  paciente_id uuid references public.pacientes(id) on delete cascade,
  cpf varchar(11) not null,
  unidade varchar(80) not null,
  senha varchar(6) not null,
  -- recepção (quem iniciou)
  recepcao jsonb default '{}',
  -- triagem (enfermeira): queixa + sinais vitais + risco
  triagem jsonb default '{}',
  -- consulta (médico)
  diagnostico text,
  cid10 varchar(10),
  conduta text,
  orientacoes text,
  receita jsonb default '[]',
  exames jsonb default '[]',
  medico_nome varchar(160),
  medico_crm varchar(30),
  -- fila / chamada
  status varchar(20) not null default 'em_fila'
    check (status in ('em_fila','chamado','em_consulta','finalizado','cancelado')),
  guiche varchar(10),
  nome_chamado varchar(160),
  chamado_em timestamptz,
  criado_em timestamptz default now(),
  finalizado_em timestamptz,
  cancelado_em timestamptz
);
create index if not exists idx_consultas_cpf on public.consultas(cpf);
create index if not exists idx_consultas_status on public.consultas(status);
create index if not exists idx_consultas_fila on public.consultas(status, criado_em);

create or replace view public.fila_espera as
  select c.*, p.nome as nome_paciente
  from public.consultas c
  left join public.pacientes p on p.id = c.paciente_id
  where c.status in ('em_fila','chamado')
  order by c.criado_em asc;

create or replace function public.posicao_fila(consulta_id uuid)
returns integer language sql stable as $$
  select count(*)
  from public.fila_espera f
  where f.criado_em <= (select criado_em from public.consultas where id = consulta_id)
    and f.status = 'em_fila'
$$;

-- ============================================================
-- 4. AGENDAMENTOS (consultas futuras marcadas pela unidade)
-- ============================================================
create table if not exists public.agendamentos (
  id uuid primary key default gen_random_uuid(),
  paciente_id uuid references public.pacientes(id) on delete cascade,
  paciente_cpf varchar(11),
  unidade varchar(80),
  especialidade varchar(80),
  data_hora timestamptz not null,
  status varchar(20) default 'agendado' check (status in ('agendado','confirmado','cancelado','concluido')),
  criado_em timestamptz default now()
);
create index if not exists idx_agendamentos_cpf on public.agendamentos(paciente_cpf);

-- ============================================================
-- 5. NOTIFICAÇÕES (central do app)
--    tipos: atendimento_iniciado | triagem | chamada | resultado | lembrete
-- ============================================================
create table if not exists public.notificacoes (
  id uuid primary key default gen_random_uuid(),
  cpf varchar(11) not null,
  tipo varchar(30) default 'aviso',
  titulo varchar(160) not null,
  texto text,
  link varchar(120),
  lida boolean default false,
  criado_em timestamptz default now()
);
create index if not exists idx_notificacoes_cpf on public.notificacoes(cpf);

-- ============================================================
-- 6. MEDICAMENTOS (estoque — opcional, para o futuro)
-- ============================================================
create table if not exists public.medicamentos (
  id uuid primary key default gen_random_uuid(),
  nome varchar(160) not null,
  principio_ativo varchar(160),
  dosagem varchar(40),
  quantidade_estoque integer default 0,
  estoque_minimo integer default 10,
  atualizado_em timestamptz default now()
);

-- ============================================================
-- SEGURANÇA (Row Level Security)
--  • PACIENTE (app): lê o próprio cadastro, consultas, exames,
--    agendamentos e notificações; pode cancelar a própria
--    consulta na fila e desmarcar próprio agendamento.
--  • EQUIPE (sistema médico): acesso amplo.
-- ============================================================
alter table public.pacientes enable row level security;
alter table public.consultas enable row level security;
alter table public.usuarios enable row level security;
alter table public.agendamentos enable row level security;
alter table public.notificacoes enable row level security;
alter table public.medicamentos enable row level security;

-- Paciente lê o próprio cadastro; equipe lê todos
create policy "paciente proprio" on public.pacientes
  for select using (
    (select auth.jwt() ->> 'cpf') = cpf
    or (select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador')
  );
create policy "paciente edita proprio" on public.pacientes
  for update using ((select auth.jwt() ->> 'cpf') = cpf);
create policy "recepcao cadastra" on public.pacientes
  for insert with check (
    (select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador')
    or (select auth.jwt() ->> 'cpf') = cpf
  );

-- Consultas: paciente vê as próprias; equipe vê todas
create policy "consulta paciente" on public.consultas
  for select using (
    (select auth.jwt() ->> 'cpf') = cpf
    or (select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador')
  );
create policy "consulta inserir equipe" on public.consultas
  for insert with check ((select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));
create policy "consulta cancelar paciente" on public.consultas
  for update using (
    (select auth.jwt() ->> 'cpf') = cpf and status in ('em_fila','chamado')
  )
  with check (status in ('em_fila','chamado','cancelado'));
create policy "consulta equipe atualiza" on public.consultas
  for update using ((select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));

-- Agendamentos: paciente vê/desmarca os próprios; equipe gerencia
create policy "agendamento paciente" on public.agendamentos
  for select using ((select auth.jwt() ->> 'cpf') = paciente_cpf
    or (select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));
create policy "agendamento paciente desmarca" on public.agendamentos
  for update using ((select auth.jwt() ->> 'cpf') = paciente_cpf)
  with check (status in ('agendado','confirmado','cancelado'));
create policy "agendamento equipe" on public.agendamentos
  for all using ((select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));

-- Notificações: paciente lê/atualiza as próprias
create policy "notificacao paciente" on public.notificacoes
  for select using ((select auth.jwt() ->> 'cpf') = cpf);
create policy "notificacao paciente marca lida" on public.notificacoes
  for update using ((select auth.jwt() ->> 'cpf') = cpf)
  with check (lida = true);
create policy "notificacao insere equipe" on public.notificacoes
  for insert with check ((select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));

-- Equipe e admin acessam usuários
create policy "usuarios select" on public.usuarios
  for select using ((select auth.jwt() ->> 'perfil') in ('recepcionista','enfermeiro','medico','administrador'));
create policy "usuarios admin" on public.usuarios
  for all using ((select auth.jwt() ->> 'perfil') = 'administrador');

create policy "medicamentos equipe" on public.medicamentos
  for all using ((select auth.jwt() ->> 'perfil') in ('enfermeiro','medico','administrador'));

-- ============================================================
-- SEED (dados de exemplo)
-- ============================================================
insert into public.pacientes (cpf, nome, nascimento, sexo, telefone, email, endereco, tipo_sanguineo, alergias, doencas_cronicas, medicamentos_uso, responsavel_nome, responsavel_telefone)
values
  ('12345678909', 'Maria Oliveira Santos', '1995-04-12', 'F', '(41) 99999-1234', 'maria.demo@email.com', 'Rua das Flores, 120 — Araucária/PR', 'O+', '{Dipirona,Poeira}', '{Asma leve}', 'Salbutamol (inalador)', 'João Oliveira', '(41) 98888-1111'),
  ('98765432100', 'João Pedro da Silva', '1988-11-03', 'M', '(41) 98888-2222', 'joao.demo@email.com', 'Av. das Araucárias, 500 — Araucária/PR', 'A+', '{}', '{Hipertensão}', 'Losartana 50mg', 'Ana Silva', '(41) 97777-3333')
on conflict (cpf) do nothing;

insert into public.usuarios (nome, cpf, email, perfil, registro_profissional)
values
  ('Ana Recepção', '11122233344', 'ana.recepcao@vidaplus.com', 'recepcionista', null),
  ('Bruno Enfermeiro', '22233344455', 'bruno.enf@vidaplus.com', 'enfermeiro', 'COREN 123456'),
  ('Dr. Carlos Pereira', '33344455566', 'carlos.medico@vidaplus.com', 'medico', 'CRM 12345'),
  ('Diana Admin', '44455566677', 'diana.admin@vidaplus.com', 'administrador', null)
on conflict (email) do nothing;

-- Consulta finalizada de exemplo (com triagem, medicamentos e exames)
insert into public.consultas (paciente_id, cpf, unidade, senha, recepcao, triagem, diagnostico, cid10, conduta, orientacoes, receita, exames, medico_nome, medico_crm, status, finalizado_em, criado_em)
select p.id, p.cpf, 'UBS Central', 'B305',
       '{"criado_por":"Ana Recepção"}'::jsonb,
       '{"queixa_principal":"Dor de cabeça forte e febre","sintomas":["Febre","Dor de cabeça","Cansaço"],"tempo_sintomas":"2 dias","intensidade_dor":7,"pressao":"130/85","temperatura":38.2,"pulso":95,"saturacao":96,"classificacao_risco":"amarelo"}'::jsonb,
       'Gripe', 'J11.1', 'Repouso, hidratação e medicação sintomática.', 'Retornar se febre persistir por mais de 72h.',
       '[{"nome":"Paracetamol 750mg","dosagem":"1 comprimido","frequencia":"6/6h","duracao":"5 dias","obs":"Após as refeições"}]'::jsonb,
       '[{"nome":"Hemograma completo","status":"resultado_disponivel","resultado":"Leucocitose leve"}]'::jsonb,
       'Dr. Carlos Pereira', 'CRM 12345', 'finalizado', now() - interval '29 days', now() - interval '30 days'
from public.pacientes p where p.cpf = '12345678909' on conflict do nothing;

-- Agendamento futuro de exemplo
insert into public.agendamentos (paciente_id, paciente_cpf, unidade, especialidade, data_hora, status)
select p.id, p.cpf, 'UBS Central', 'Clínico Geral', now() + interval '5 days', 'confirmado'
from public.pacientes p where p.cpf = '12345678909' on conflict do nothing;

-- Notificação de exemplo
insert into public.notificacoes (cpf, tipo, titulo, texto, link)
values ('12345678909', 'lembrete', '🗓️ Lembrete de consulta', 'Você tem consulta com Clínico Geral na UBS Central em breve.', 'agendamentos.html')
on conflict do nothing;
