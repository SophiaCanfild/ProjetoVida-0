// ============================================================
// Edge Function: enviar-notificacao
// ------------------------------------------------------------
// Disparada pelo TELÃO (sistema médico) quando chama um paciente.
// Envia push notification REAL (OneSignal) para o celular do
// paciente + registra a chamada no banco (guichê, horário).
//
// COMO CONFIGURAR:
// 1. Criar o app no OneSignal (Web Push) e copiar o App ID
// 2. No Supabase: Project Settings → Edge Functions →
//    Secrets → adicionar ONESIGNAL_REST_API_KEY
// 3. Deploy: supabase functions deploy enviar-notificacao
//
// CHAMADA (do sistema médico / telão):
//   POST /functions/v1/enviar-notificacao
//   { "consulta_id": "uuid", "guiche": "1" }
// ============================================================

Deno.serve(async (req) => {
  try {
    const { consulta_id, guiche } = await req.json();

    // 1. Busca a consulta + paciente no banco
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const { data: consulta, error } = await supabaseQuery(supabaseUrl, supabaseKey, consulta_id);
    if (error || !consulta) {
      return json({ ok: false, erro: 'Consulta não encontrada' }, 404);
    }

    const { id, cpf, senha, unidade, paciente_id } = consulta;

    // 2. Marca a consulta como CHAMADO
    await supabaseUpdate(supabaseUrl, supabaseKey, id, {
      status: 'chamado',
      guiche: guiche || '1',
      nome_chamado: consulta.nome_paciente,
      chamado_em: new Date().toISOString()
    });

    // 3. Dispara o push no OneSignal
    const onesignalKey = Deno.env.get('ONESIGNAL_REST_API_KEY');
    const onesignalAppId = Deno.env.get('ONESIGNAL_APP_ID');

    if (onesignalKey && onesignalAppId) {
      const resposta = await fetch('https://api.onesignal.com/notifications?c=push', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': `Basic ${onesignalKey}`
        },
        body: JSON.stringify({
          app_id: onesignalAppId,
          // O app registra o CPF como tag ao logar (OneSignal.sendTag('cpf', ...))
          filters: [{ field: 'tag', key: 'cpf', relation: '=', value: cpf }],
          headings: { en: '🔔 Sua vez chegou!', pt: '🔔 Sua vez chegou!' },
          contents: {
            en: `${consulta.nome_paciente} — Senha ${senha} • Guichê ${guiche || 1}`,
            pt: `${consulta.nome_paciente} — Senha ${senha} • Guichê ${guiche || 1}`
          },
          url: 'fila.html',
          ios_sound: 'default',
          android_sound: 'default'
        })
      });
      const corpo = await resposta.json();
      return json({ ok: true, consulta: id, push: corpo });
    }

    return json({ ok: true, consulta: id, push: 'OneSignal não configurado (fallback do app cobre)' });
  } catch (e) {
    return json({ ok: false, erro: String(e) }, 500);
  }
});

/* ---- helpers (Supabase REST direto, sem SDK) ---- */
async function supabaseQuery(url: string, key: string, consultaId: string) {
  const r = await fetch(`${url}/rest/v1/consultas?select=*,pacientes(nome)&id=eq.${consultaId}`, {
    headers: { apikey: key, Authorization: `Bearer ${key}` }
  });
  const data = await r.json();
  const linha = Array.isArray(data) ? data[0] : null;
  return {
    data: linha ? { ...linha, nome_paciente: linha.pacientes?.nome } : null,
    error: !r.ok ? data : null
  };
}

async function supabaseUpdate(url: string, key: string, consultaId: string, campos: Record<string, unknown>) {
  await fetch(`${url}/rest/v1/consultas?id=eq.${consultaId}`, {
    method: 'PATCH',
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', Prefer: 'return=minimal' },
    body: JSON.stringify(campos)
  });
}

function json(obj: unknown, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } });
}
